


// start pass required
var pass_required = document.querySelector('.pass_required_page .btn_pass_req')
pass_required.onclick = function(){
    if(document.querySelector('.pass_required_page input').value != ""){
    
    }
    
}
// end pass required




