
// start All_requirement page
    // start confirm button 

    var confirm_btn  = document.querySelector('.All_Requirements_page .btn-confirm_req');
    console.log(confirm_btn)
    confirm_btn.onclick = function(){
        confirm('هل تريد تأكيد الطلب؟ ')
    }


// end All_requirement page
    // end confirm button 

